# Roadmap suPrompts – implémentation des idées

## Objectifs généraux

- Clarifier et structurer les fonctionnalités à implémenter.
- Prioriser les "quick wins" pour améliorer rapidement l’expérience.
- Prévoir une montée en complexité progressive (persistance, formats, analyse avancée).

---

## Phase 1 – Quick wins UX/UI (améliorations visibles rapides)

### 1.1. Bouton "Copy full prompt"

- Ajouter un bouton bien visible dans la colonne de droite.
- Action : copier l’intégralité du contenu du prompt dans le presse-papiers.
- Afficher un petit message de confirmation (ex. "Prompt copié").

### 1.2. Lisibilité et hiérarchie visuelle

- Renforcer la séparation visuelle entre les trois colonnes (légères bordures / espacements / fonds).
- Mettre davantage en avant les titres de colonnes (taille, couleur, alignement).
- Vérifier le comportement responsive minimum (taille fenêtre réduite sur desktop).

### 1.3. Confort d’édition des cartes

- Ajuster la hauteur des `textarea` (valeur par défaut + possibilité de resize).
- Ajouter un bouton "Clear" par carte pour vider rapidement le contenu.
- Afficher le nombre de caractères par carte (indication légère).

**Critère de fin de phase 1 :**

- Copier-coller du prompt possible en un clic.
- L’interface est plus lisible et agréable sans refonte majeure.

---

## Phase 2 – Persistance et gestion de prompts

### 2.1. Sauvegarde automatique (localStorage)

- Définir un schéma de données pour un "prompt" (sections + contenu + métadonnées de base).
- À chaque modification de carte, sauvegarder l’état courant dans `localStorage`.
- Au chargement de la page, restaurer automatiquement le dernier prompt.

### 2.2. Liste de prompts récents / favoris

- Ajouter une petite zone (ou modal) pour lister les prompts disponibles (titre + date).
- Permettre :
  - Charger un prompt existant.
  - Supprimer un prompt.
  - Marquer un prompt comme "favori".

### 2.3. Export / import JSON

- Implémenter un bouton "Exporter" qui génère un fichier `.json` du prompt courant.
- Implémenter un bouton "Importer" qui permet de charger un `.json` et remplir les cartes.
- Valider la structure du JSON avant import (messages d’erreur clairs).

**Critère de fin de phase 2 :**

- L’utilisateur ne perd plus son travail en fermant l’onglet.
- Il peut sauvegarder, recharger, exporter et importer ses prompts.

---

## Phase 3 – Formats, templates et qualité du prompt

### 3.1. Support d’autres formats de sortie

- Ajouter au sélecteur de format : JSON et YAML.
- Définir un mapping clair des sections vers les clés du JSON/YAML.
- Générer une sortie bien formattée (indentation, guillemets, échappement basique).

### 3.2. Templates / modes prédéfinis

- Définir quelques templates de base :
  - Question simple.
  - Analyse de texte.
  - Génération de code.
  - Agent / outil (persona + instructions + format strict).
- Au choix d’un template :
  - Préconfigurer les sections actives / leur ordre.
  - Pré-remplir éventuellement certains textes d’exemple.

### 3.3. Sections obligatoires vs optionnelles + checklist de qualité

- Marquer dans l’UI les sections recommandées (ex. Goal, Context) vs optionnelles.
- Afficher un indicateur de complétude (X sections remplies sur Y recommandées).
- Messages d’avertissement légers :
  - "Pas de contexte fourni".
  - "Aucun exemple donné".

**Critère de fin de phase 3 :**

- L’utilisateur peut choisir un mode d’usage adapté à son cas.
- La sortie est disponible dans plusieurs formats.
- L’outil l’aide à construire des prompts plus complets.

---

## Phase 4 – Historique, versions et fonctionnalités avancées

### 4.1. Historique et versions de prompts

- Mettre en place un système de snapshots (versionnage léger) :
  - Sauvegarde manuelle (bouton "Sauvegarder une version").
  - Ou snapshots automatiques à certains moments clés.
- Interface pour :
  - Lister les versions d’un même prompt.
  - Consulter le contenu d’une version.
  - Restaurer une version.

### 4.2. Comparaison A/B de prompts

- Permettre de dupliquer un prompt pour créer une variante.
- Vue de comparaison côte à côte :
  - Sections alignées.
  - Possibilité de copier une section de A vers B.

### 4.3. Analyse automatique (future intégration API)

- Concevoir l’interface pour :
  - Afficher un "score de qualité" du prompt.
  - Afficher des recommandations (ex. manque d’exemples, contraintes floues).
- Prévoir un point d’extension pour brancher ultérieurement une API d’analyse.

### 4.4. Revoir la disposition des outils

- Simplifier la zone de sauvegarde :

  - Mettre en place un nouveau modèle de sauvegarde basé sur des variantes de prompts :
    - Rendre le champ « Nom du prompt » **obligatoire** pour toute sauvegarde.
    - Bouton « Sauvegarder » :
      - Si le champ est vide : demander un nom (message / dialogue) et ne pas sauvegarder tant qu’il est vide.
      - Si un prompt portant ce nom existe déjà : mettre à jour ce prompt avec l’état courant (sans créer de version horodatée).
      - Si aucun prompt ne porte encore ce nom : créer un nouveau prompt nommé avec l’état courant.
    - Bouton « Version » :
      - Si le champ est vide : demander un nom comme pour « Sauvegarder ».
      - Si le nom n’existe pas encore : sauvegarder d’abord ce nom comme prompt de base.
      - Calculer un nom de variante en suffixant le nom de base (`Nom`, `Nom_1`, `Nom_2`, …) en prenant le prochain indice disponible.
      - Créer un nouveau prompt avec ce nom de variante en dupliquant l’état courant, puis basculer le champ de nom et la sélection sur cette variante.
    - Cesser de créer de nouvelles versions horodatées dans le système de versions interne, tout en continuant à lire/afficher les anciennes versions existantes pour ne pas perdre les données locales.

- Regrouper les outils avancés derrière une icône / zone escamotable :

  - Masquer par défaut :
    - Export JSON.
    - Import JSON.
    - Liste détaillée des prompts (sélecteur, suppression, favori, etc.).
  - Afficher ces outils au survol / clic sur une icône (ex. engrenage ou « Outils avancés »).

- Réorganiser les contrôles autour du prompt final :

  - Mettre sur la même ligne :
    - Sélecteur de format (Markdown / XML / JSON / YAML).
    - Sélecteur de modèle (template).
  - Placer ces contrôles à proximité du prompt final pour renforcer le lien visuel.

- Unifier les actions principales sur le prompt :

  - Aligner sur une même ligne :
    - Bouton « Compare » (A/B).
    - Bouton « Copy full prompt ».

- Fusionner les recommandations dans un seul panneau de qualité :
  - Regrouper l’indicateur de complétude et l’analyse automatique.
  - Afficher :
    - Un indicateur de complétude (sections recommandées remplies).
    - Un score sur 100.
    - Une seule liste de recommandations (problèmes détectés + pistes d’amélioration).

### 4.5. Étoffer les modèles proposés

- Améliorer les templates existants :

  - Clarifier les textes par défaut (objectif, contexte, contraintes).
  - Ajouter des exemples concrets là où c’est pertinent.
  - Mieux expliciter le ton et le format attendu.

- Créer des profils de modèles « atypiques » :

  - Profils de critique :
    - Critique sévère (très exigeant, axé sur les faiblesses).
    - Critique bienveillant (constructif, met en avant les forces).
    - « Avocat du diable » (cherche les failles et contre-arguments).
  - Profils pédagogiques :
    - Tuteur socratique (pose surtout des questions).
    - Coach pour débutant (explications très guidées).
  - Profils de validation :
    - Vérificateur de contraintes (checklist stricte des règles à respecter).
    - Relecteur de clarté (se focalise sur la compréhension par un lecteur humain).

- Structurer les templates dans le code pour faciliter les ajouts futurs :
  - Centraliser tous les modèles dans une structure unique (objet de configuration).
  - Prévoir des champs pour :
    - Persona.
    - Goal / objectif.
    - Contexte.
    - Contraintes.
    - Format de sortie.
    - Exemples.

### 4.6. Durcissement & francisation

#### 4.6.1. Nettoyage et factorisation du code

- Supprimer les éléments obsolètes ou non utilisés (anciens panneaux, sélecteurs redondants, variables DOM inutilisées, fonctions mortes).
- Factoriser les morceaux de logique dupliqués lorsque c’est pertinent (ex. formatage de dates, tri des listes, utilitaires partagés entre prompts nommés / versions / overlay A/B).
- Clarifier la structure de `main_v2.js` en regroupant les sections par grande fonctionnalité (cartes, persistance, prompts nommés, versions, templates, analyse, A/B, responsive) et en ajoutant des séparateurs lisibles.

#### 4.6.2. Francisation et cohérence de l’interface

- Passer en revue tous les textes visibles dans l’interface (titres, boutons, tooltips, messages) et les traduire / harmoniser en français.
- Vérifier la cohérence du vocabulaire employé (ex. : « prompt » vs « consigne », « modèle » vs « template ») et choisir une terminologie stable.
- Laisser le code, les commentaires et les docstrings en anglais (convention technique), tout en gardant l’interface utilisateur en français.

#### 4.6.3. Mini audit de sécurité (front local)

- Vérifier l’absence d’insertions HTML non contrôlées à partir de contenu utilisateur (préférer `textContent` à `innerHTML` dès que possible).
- Vérifier le flux d’import JSON (validation minimale des champs avant utilisation, gestion des erreurs de parsing, absence d’exécution de contenu arbitraire).
- Vérifier l’usage de `localStorage` (clés dédiées à l’application, pas d’enregistrement de données sensibles, gestion propre des structures stockées).
- Documenter une courte checklist de points de vigilance sécurité à relire avant chaque évolution majeure.

**Critère de fin de phase 4 :**

- L’utilisateur peut travailler sur plusieurs variantes.
- L’outil l’aide à améliorer ses prompts de manière plus intelligente.

---

## Phase 5 – Responsive et expérience multi-device

### 5.1. Comportement sur petits écrans

- Définir le comportement cible sur mobile / petites fenêtres :
  - Passage éventuel à une vue en onglets (Sections / Édition / Prompt final).
  - Ajustement des marges, tailles de police et hauteurs de blocs.
- Tester sur plusieurs largeurs (mobile, tablette, desktop).

### 5.2. Finitions UI

- Ajuster les espacements, contrastes et alignements.
- Ajouter éventuellement des icônes aux cartes de section (persona, contraintes, etc.).
- Ajouter des tooltips avec exemples concrets au survol des sections.

**Critère de fin de phase 5 :**

- L’application reste utilisable et confortable sur des résolutions variées.

---

## Notes de mise en œuvre

- Commencer chaque phase par de petites tâches isolées (PRs courtes, faciles à tester).
- Ajouter progressivement des tests manuels (et éventuellement automatisés) au fur et à mesure.
- Toujours vérifier que le comportement de base (création de cartes, génération de prompt) reste intact après chaque changement.
