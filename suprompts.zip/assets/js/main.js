const paragraphCards = document.querySelectorAll('.paragraph-card');
const cardsContainer = document.getElementById('cards-container');
const promptOutput = document.getElementById('prompt-output');
const languageSelector = document.getElementById('language');
const copyPromptButton = document.getElementById('copy-prompt-btn');
const copyFeedback = document.getElementById('copy-feedback');
const promptNameInput = document.getElementById('prompt-name-input');
const savePromptButton = document.getElementById('save-prompt-btn');
const savedPromptsSelect = document.getElementById('saved-prompts-select');
const loadPromptButton = document.getElementById('load-prompt-btn');
const deletePromptButton = document.getElementById('delete-prompt-btn');
const favoritePromptButton = document.getElementById('favorite-prompt-btn');
const exportPromptButton = document.getElementById('export-prompt-btn');
const importPromptInput = document.getElementById('import-prompt-input');
const templateSelector = document.getElementById('template-select');
const completionIndicator = document.getElementById('completion-indicator');
const qualityWarnings = document.getElementById('quality-warnings');
const saveVersionButton = document.getElementById('save-version-btn');
const versionsSelect = document.getElementById('versions-select');
const loadVersionButton = document.getElementById('load-version-btn');
const deleteVersionButton = document.getElementById('delete-version-btn');
const abOpenButton = document.getElementById('ab-open-btn');
const abOverlay = document.getElementById('ab-overlay');
const abCloseButton = document.getElementById('ab-close-btn');
const abLeftCardsContainer = document.getElementById('ab-left-cards');
const abRightPrompt = document.getElementById('ab-right-prompt');
const abApplyRightToLeftButton = document.getElementById('ab-apply-right-to-left');
const abTemplatesList = document.getElementById('ab-templates-list');
const abNamedPromptsList = document.getElementById('ab-named-prompts-list');
const abVersionsList = document.getElementById('ab-versions-list');

const STORAGE_KEY = 'suprompts_storage_v1';

const RECOMMENDED_SECTIONS = ['Goal', 'Context', 'Examples'];

const TEMPLATES = {
    'simple-question': {
        sections: ['Persona', 'Goal', 'Context', 'Constraints', 'Format', 'Tone'],
        presets: {
            Persona: 'Tu es un assistant qui répond aux questions de manière claire et concise.',
            Goal: "Répondre précisément à la question posée par l’utilisateur.",
            Context: '',
            Constraints: '',
            Format: '',
            Tone: 'Ton amical et pédagogique.'
        }
    },
    'text-analysis': {
        sections: ['Persona', 'Goal', 'Context', 'Examples', 'Constraints', 'Format'],
        presets: {
            Persona: 'Tu es un expert en analyse de texte.',
            Goal: 'Analyser, résumer et extraire les éléments clés du texte fourni.',
            Context: '',
            Examples: '',
            Constraints: '',
            Format: 'Fournis un résumé structuré avec des puces.'
        }
    },
    'code-generation': {
        sections: ['Persona', 'Goal', 'Context', 'Constraints', 'Format', 'Examples'],
        presets: {
            Persona: 'Tu es un développeur senior qui écrit du code robuste et lisible.',
            Goal: 'Générer du code qui répond au besoin décrit.',
            Context: '',
            Constraints: 'Respecte les conventions du langage et ajoute des vérifications d’erreurs simples.',
            Format: 'Retourne uniquement le code, sans explication, dans un bloc de code.',
            Examples: ''
        }
    },
    'agent-tool': {
        sections: ['Persona', 'Goal', 'Context', 'Constraints', 'Format', 'Tone'],
        presets: {
            Persona: 'Tu es un agent chargé d’utiliser des outils pour accomplir une mission donnée.',
            Goal: 'Planifier et exécuter les actions nécessaires pour atteindre l’objectif de l’utilisateur.',
            Context: '',
            Constraints: 'Suis strictement les étapes demandées et ne sors pas du rôle d’agent.',
            Format: 'Présente le raisonnement sous forme de liste d’étapes, puis la réponse finale séparément.',
            Tone: 'Professionnel et factuel.'
        }
    }
};

let storageData = {
    lastSession: null,
    prompts: {},
    versions: {}
};

let cards = [];
let abRightSelection = null;
let abRightCardsSnapshot = null;
let abRightLanguage = null;

paragraphCards.forEach(card => {
    card.addEventListener('click', () => {
        const paragraphType = card.dataset.paragraph;
        addCard(paragraphType);
    });
});

if (languageSelector) {
    languageSelector.addEventListener('change', updatePrompt);
}

if (copyPromptButton) {
    copyPromptButton.addEventListener('click', () => {
        if (!promptOutput) {
            return;
        }

        const textToCopy = promptOutput.textContent || '';

        if (!textToCopy.trim()) {
            showCopyFeedback('Nothing to copy', true);
            return;
        }

        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard
                .writeText(textToCopy)
                .then(() => {
                    showCopyFeedback('Prompt copied');
                })
                .catch(() => {
                    showCopyFeedback('Unable to copy prompt', true);
                });
        } else {
            const helper = document.createElement('textarea');
            helper.value = textToCopy;
            helper.setAttribute('readonly', '');
            helper.style.position = 'absolute';
            helper.style.left = '-9999px';
            document.body.appendChild(helper);
            helper.select();

            try {
                document.execCommand('copy');
                showCopyFeedback('Prompt copied');
            } catch (e) {
                showCopyFeedback('Unable to copy prompt', true);
            }

            document.body.removeChild(helper);
        }
    });
}

if (savePromptButton) {
    savePromptButton.addEventListener('click', () => {
        saveNamedPrompt();
    });
}

if (loadPromptButton && savedPromptsSelect) {
    loadPromptButton.addEventListener('click', () => {
        const name = savedPromptsSelect.value;
        if (!name) {
            return;
        }
        loadNamedPrompt(name);
    });
}

if (deletePromptButton && savedPromptsSelect) {
    deletePromptButton.addEventListener('click', () => {
        const name = savedPromptsSelect.value;
        if (!name) {
            return;
        }
        deleteNamedPrompt(name);
    });
}

if (favoritePromptButton) {
    favoritePromptButton.addEventListener('click', () => {
        const name = (savedPromptsSelect && savedPromptsSelect.value) || (promptNameInput && promptNameInput.value.trim());
        if (!name) {
            return;
        }
        toggleFavoriteByName(name);
    });
}

if (exportPromptButton) {
    exportPromptButton.addEventListener('click', () => {
        exportCurrentPromptAsJson();
    });
}

if (importPromptInput) {
    importPromptInput.addEventListener('change', () => {
        const file = importPromptInput.files && importPromptInput.files[0];
        if (!file) {
            return;
        }

        const reader = new FileReader();
        reader.onload = () => {
            try {
                const data = JSON.parse(String(reader.result));
                importPromptFromData(data, file.name);
            } catch (e) {
                // ignore invalid JSON
            } finally {
                importPromptInput.value = '';
            }
        };
        reader.readAsText(file);
    });
}

if (templateSelector) {
    templateSelector.addEventListener('change', () => {
        const templateId = templateSelector.value;
        if (!templateId) {
            return;
        }
        applyTemplate(templateId);
    });
}

if (saveVersionButton) {
    saveVersionButton.addEventListener('click', () => {
        saveCurrentVersion();
    });
}

if (loadVersionButton && versionsSelect) {
    loadVersionButton.addEventListener('click', () => {
        const versionId = versionsSelect.value;
        if (!versionId) {
            return;
        }
        loadVersionById(versionId);
    });
}

if (deleteVersionButton && versionsSelect) {
    deleteVersionButton.addEventListener('click', () => {
        const versionId = versionsSelect.value;
        if (!versionId) {
            return;
        }
        deleteVersionById(versionId);
    });
}

if (promptNameInput) {
    promptNameInput.addEventListener('input', () => {
        refreshVersionsSelect();
    });
}

if (savedPromptsSelect) {
    savedPromptsSelect.addEventListener('change', () => {
        refreshVersionsSelect();
    });
}

if (abOpenButton && abOverlay) {
    abOpenButton.addEventListener('click', () => {
        openABOverlay();
    });
}

if (abCloseButton && abOverlay) {
    abCloseButton.addEventListener('click', () => {
        closeABOverlay();
    });
}

if (abApplyRightToLeftButton) {
    abApplyRightToLeftButton.addEventListener('click', () => {
        applyRightPromptToLeft();
    });
}

function addCard(type) {
    // Prevent adding duplicate cards
    if (cards.some(card => card.type === type)) {
        return;
    }

    const card = {
        id: Date.now(),
        type,
        content: ''
    };

    cards.push(card);
    renderCards();
    updatePrompt();
}

function removeCard(target) {
    cards = cards.filter(card => card !== target);
    renderCards();
    updatePrompt();
}

function updateCardContent(target, content) {
    if (!target) {
        return;
    }
    target.content = content;
    updatePrompt();
}

function renderCards() {
    // Sort cards based on the order in the left panel
    const order = Array.from(paragraphCards).map(card => card.dataset.paragraph);
    cards.sort((a, b) => order.indexOf(a.type) - order.indexOf(b.type));

    cardsContainer.innerHTML = '';
    cards.forEach(card => {
        const cardElement = document.createElement('div');
        cardElement.className = 'card';
        cardElement.innerHTML = `
      <h3>${card.type}</h3>
      <textarea data-id="${card.id}" placeholder="Enter content for ${card.type}...">${card.content}</textarea>
      <div class="card-footer">
        <span class="char-count">${(card.content || '').length} characters</span>
        <div>
          <button class="clear-btn" data-id="${card.id}">Clear</button>
          <button class="remove-btn" data-id="${card.id}">Remove</button>
        </div>
      </div>
    `;
        cardsContainer.appendChild(cardElement);

        const textarea = cardElement.querySelector('textarea');
        const charCount = cardElement.querySelector('.char-count');
        const clearButton = cardElement.querySelector('.clear-btn');
        const removeButton = cardElement.querySelector('.remove-btn');

        const updateCharCount = () => {
            if (charCount) {
                charCount.textContent = `${textarea.value.length} characters`;
            }
        };

        updateCharCount();

        textarea.addEventListener('input', () => {
            updateCardContent(card, textarea.value);
            updateCharCount();
        });

        if (clearButton) {
            clearButton.addEventListener('click', () => {
                textarea.value = '';
                updateCardContent(card, '');
                updateCharCount();
            });
        }

        if (removeButton) {
            removeButton.addEventListener('click', () => {
                removeCard(card);
            });
        }
    });
}

function showCopyFeedback(message, isError) {
    if (!copyFeedback) {
        return;
    }

    copyFeedback.textContent = message;

    if (isError) {
        copyFeedback.style.color = '#e74c3c';
    } else {
        copyFeedback.style.color = '';
    }

    clearTimeout(showCopyFeedback._timeoutId);
    showCopyFeedback._timeoutId = setTimeout(() => {
        copyFeedback.textContent = '';
    }, 2000);
}

function updatePrompt() {
    if (!promptOutput || !languageSelector) {
        return;
    }

    const language = languageSelector.value;
    let promptText = '';

    const order = Array.from(paragraphCards).map(card => card.dataset.paragraph);
    const sortedCards = [...cards].sort((a, b) => order.indexOf(a.type) - order.indexOf(b.type));

    if (language === 'markdown') {
        sortedCards.forEach(card => {
            if (card.content) {
                promptText += `## ${card.type}\n\n${card.content}\n\n`;
            }
        });
    } else if (language === 'xml') {
        promptText += '<prompt>\n';
        sortedCards.forEach(card => {
            if (card.content) {
                promptText += `    <${card.type.toLowerCase()}>${card.content}</${card.type.toLowerCase()}>\n`;
            }
        });
        promptText += '</prompt>';
    } else if (language === 'json') {
        const obj = {};
        sortedCards.forEach(card => {
            if (card.content && card.content.trim()) {
                obj[card.type.toLowerCase()] = card.content;
            }
        });
        promptText = JSON.stringify(obj, null, 2);
    } else if (language === 'yaml') {
        const lines = [];
        sortedCards.forEach(card => {
            if (card.content && card.content.trim()) {
                const key = card.type.toLowerCase();
                lines.push(key + ': |');
                card.content.split('\n').forEach(line => {
                    lines.push('  ' + line);
                });
            }
        });
        promptText = lines.join('\n');
    }

    promptOutput.textContent = promptText;

    saveLastSession();
    updateQualityIndicator();
}

function loadStorage() {
    try {
        if (!window.localStorage) {
            storageData = {
                lastSession: null,
                prompts: {},
                versions: {}
            };
            return;
        }
        const raw = window.localStorage.getItem(STORAGE_KEY);
        if (!raw) {
            storageData = {
                lastSession: null,
                prompts: {},
                versions: {}
            };
            return;
        }
        const parsed = JSON.parse(raw);
        storageData = {
            lastSession: parsed && parsed.lastSession ? parsed.lastSession : null,
            prompts: parsed && parsed.prompts && typeof parsed.prompts === 'object' ? parsed.prompts : {},
            versions: parsed && parsed.versions && typeof parsed.versions === 'object' ? parsed.versions : {}
        };
    } catch (e) {
        storageData = {
            lastSession: null,
            prompts: {},
            versions: {}
        };
    }
}

function saveStorage() {
    try {
        if (!window.localStorage) {
            return;
        }
        const data = {
            lastSession: storageData.lastSession,
            prompts: storageData.prompts,
            versions: storageData.versions || {}
        };
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
        // ignore storage errors
    }
}

function saveLastSession() {
    storageData.lastSession = {
            language: languageSelector ? languageSelector.value : 'markdown',
            cards: cards.map(card => ({
                            type: card.type,
                            content: card.content || ''
                            storageData.versions = {};
                        }
                        if (!storageData.versions[key]) {
                            storageData.versions[key] = [];
                        }

                        const now = new Date();
                        const version = {
                            id: String(now.getTime()),
                            createdAt: now.toISOString(),
                            language: languageSelector.value,
                            cards: cards.map(card => ({
                                type: card.type,
                                content: card.content || ''
                            }))
                        };

                        storageData.versions[key].push(version); saveStorage(); refreshVersionsSelect();

                        if (versionsSelect) {
                            versionsSelect.value = version.id;
                        }
                    }

                    function refreshVersionsSelect() {
                        if (!versionsSelect) {
                            return;
                        }

                        versionsSelect.innerHTML = '';

                        const placeholder = document.createElement('option');
                        placeholder.value = '';
                        placeholder.textContent = 'Select a version...';
                        versionsSelect.appendChild(placeholder);

                        if (!storageData.versions) {
                            storageData.versions = {};
                        }

                        const key = getCurrentPromptKey();
                        const list = storageData.versions[key] ? [...storageData.versions[key]] : [];

                        list.sort((a, b) => {
                            const at = a.createdAt ? new Date(a.createdAt).getTime() : 0;
                            const bt = b.createdAt ? new Date(b.createdAt).getTime() : 0;
                            return bt - at;
                        });

                        list.forEach(version => {
                            const option = document.createElement('option');
                            option.value = version.id;
                            const labelDate = version.createdAt ? new Date(version.createdAt).toLocaleString() : version.id;
                            option.textContent = labelDate;
                            versionsSelect.appendChild(option);
                        });
                    }

                    function loadVersionById(versionId) {
                        if (!storageData.versions) {
                            return;
                        }
                        const key = getCurrentPromptKey();
                        const list = storageData.versions[key];
                        if (!list) {
                            return;
                        }

                        const version = list.find(v => v.id === versionId);
                        if (!version) {
                            return;
                        }

                        cards = (version.cards || []).map(card => ({
                            type: card.type,
                            content: card.content || ''
                        }));

                        if (languageSelector && version.language) {
                            languageSelector.value = version.language;
                        }

                        renderCards();
                        updatePrompt();
                    }

                    function deleteVersionById(versionId) {
                        if (!storageData.versions) {
                            return;
                        }
                        const key = getCurrentPromptKey();
                        const list = storageData.versions[key];
                        if (!list) {
                            return;
                        }

                        storageData.versions[key] = list.filter(v => v.id !== versionId);
                        saveStorage();
                        refreshVersionsSelect();
                    }

                    loadStorage(); initializeFromStorage(); refreshSavedPromptsSelect(); refreshVersionsSelect();